// api/generate.ts
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';

const AI_MODEL = 'gemini-2.5-flash-image'; // match your model string in code

export default async function handler(req: VercelRequest, res: VercelResponse) {
    try {
        if (req.method !== 'POST') {
            res.status(405).json({ error: 'Method not allowed' });
            return;
        }

        const body = req.body;
        // Expect JSON: { imageData: "data:<mime>;base64,<base64>", templateId: "...", templateOptions: {...} }
        const { imageData, templateId, templateOptions } = body;

        if (!imageData) {
            res.status(400).json({ error: 'Missing imageData' });
            return;
        }

        // Extract base64 and mime
        const match = /^data:(.+);base64,(.*)$/.exec(imageData);
        if (!match) {
            res.status(400).json({ error: 'imageData must be a data URL (data:...;base64,...)' });
            return;
        }
        const mimeType = match[1];
        const base64Data = match[2];

        const apiKey = process.env.GOOGLE_API_KEY;
        if (!apiKey) {
            console.error('Missing GOOGLE_API_KEY in env');
            res.status(500).json({ error: 'Server misconfiguration' });
            return;
        }

        const ai = new GoogleGenAI({ apiKey });

        // Build parts to include the user image inline
        const parts = [
            {
                type: 'IMAGE',
                // Gemini server API-friendly payload: inlineData
                inlineData: {
                    mimeType,
                    data: base64Data,
                },
            },
            // Add any instruction text part if your template expects it
            ...(templateOptions?.text ? [{ type: 'TEXT', text: templateOptions.text }] : []),
        ];

        // Build the generation request -- adjust per your original templates/config
        const response = await ai.models.generateContent({
            model: AI_MODEL,
            contents: { parts },
            config: {
                imageConfig: {
                    // set width/height/aspect ratio if you want
                    aspectRatio: templateOptions?.aspectRatio ?? 1,
                },
                // you can pass other generation config here
            },
        });

        // Parse Gemini response and return base64 data URLs
        const candidates = response.candidates ?? [];
        const urls = [];
        for (const c of candidates) {
            const part = c?.content?.parts?.find((p: any) => p.inlineData);
            if (part?.inlineData?.data) {
                urls.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
            }
        }

        if (urls.length === 0) {
            res.status(500).json({ error: 'No images generated (blocked or empty response)' });
            return;
        }

        res.status(200).json({ images: urls });
    } catch (err: any) {
        console.error('API /api/generate error:', err);
        res.status(500).json({ error: err?.message ?? 'Unknown error' });
    }
}
