// services/geminiService.ts (client-side)
export async function generateRemixOnServer(imageFile: File, templateId: string, templateOptions?: any) {
  // convert file -> data URL
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Failed reading image'));
    reader.readAsDataURL(imageFile);
  });

  const resp = await fetch('/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      imageData: dataUrl,
      templateId,
      templateOptions
    }),
  });

  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err?.error ?? 'Generation failed');
  }
  const { images } = await resp.json();
  return images; // array of data URLs
}
